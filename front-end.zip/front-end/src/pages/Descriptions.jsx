import React from 'react';
import '../styles/App.css'; 
import { useAuth0 } from "@auth0/auth0-react";
import { useNavigate } from "react-router-dom";
import { jwtDecode } from 'jwt-decode';
import Token from "../components/token"
import { useState, useEffect } from 'react';

const Descriptions = () => {


}

export default Descriptions;